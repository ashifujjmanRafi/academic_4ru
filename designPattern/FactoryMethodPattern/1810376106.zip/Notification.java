public interface Notification {
    public void notifyUser(String msg);
}