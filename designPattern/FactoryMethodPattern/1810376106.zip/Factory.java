
public abstract class Factory {
    abstract Notification createNotification(String notificationType) ;
}